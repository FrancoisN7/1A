#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h> /* wait */
#include <stdbool.h>
#include "readcmd.h"
#include "readcmd.c"
#include <string.h>
#include <signal.h>
#include "fcntl.h"


/*------------------Définition des paramètres------------------------------------------*/
#define CAPACITE 200 //Capacité de la liste
int nbProc = 1; 

//Définition du type Etat
typedef enum {
    Suspendu,Actif,Erreur
} T_Etat;
T_Etat Etat_t;

//Définition du type processus
typedef struct Processus {
    pid_t pidProc;
    T_Etat etatProc;
    char* commandeProc; 
    } Processus;  
typedef Processus listeProc_t[CAPACITE];

/* variable globale car modifiée par le traitant */
listeProc_t listeProc; 
struct cmdline *commande;
pid_t pidFils, commande_avant_plan;

bool ctrlC, ctrlZ; //Booleens liés à l'arrêt d'un processus en avant plan

/*-----------------Fonctions utiles à l'affichage--------------------------------------*/
//Traduit l'état d'entier 1/0 à Actif/Suspendu
char* traduireEtat(T_Etat etat){
    char* Etat = "Actif";
    if (etat == Suspendu){
        Etat = "Suspendu";
    }
    if ((etat != Suspendu) && (etat != Actif)){
        Etat = "Erreur";
    }
    return(Etat);
}

//Ajouter nbEspace espaces
void ajouterEspace(int nbEspace){
    for (int i=0;i<nbEspace;i++){
        printf(" ");
    }
}

//Trouver la taille que représente un entier quand on l'affiche
int trouverTaille(int entier){
    int taille=0;
    while (entier != 0){
        entier = entier/10;
        taille++;
    }
    return taille;
}

//Afficher la liste des processus
void afficherListeProc(listeProc_t listeProc){
    int nb_espaces = 8;
    char* Etat;
    printf("Numéro");
    ajouterEspace(nb_espaces);
    printf("Pid");
    ajouterEspace(nb_espaces); 
    printf("Etat");
    ajouterEspace(nb_espaces);
    printf("Commande\n");
    for (int i=1; i<CAPACITE; i++){
        if (listeProc[i-1].commandeProc != NULL){
            if (listeProc[i-1].etatProc != Erreur){
                //Afficher le numéro du processus
                printf("%i",i);
                ajouterEspace(nb_espaces-1+strlen("Numéro")-trouverTaille(i));
                //Afficher le pid du processus
                printf("%i",listeProc[i-1].pidProc);
                ajouterEspace(nb_espaces+strlen("Pid")-
                trouverTaille((int)listeProc[i-1].pidProc));
                //Afficher l'Etat du processus
                Etat = traduireEtat(listeProc[i-1].etatProc);
                printf("%s",Etat);
                ajouterEspace(nb_espaces+strlen("Etat")-strlen(Etat));
                //Afficher la commande
                printf("%s\n", listeProc[i-1].commandeProc);
            }
        }
    }
}



/*-----------------Sous-programmes utiles pour le main---------------------------------*/
/*----Sous-programmes pour lj----*/
//Parcourir la liste pour trouver le bon Processus
//Ici le pid correspond forcément à un élément de la liste 
int TrouverProc(listeProc_t listeProc, int pid){
    int ind=0;
    while (listeProc[ind].pidProc != pid){
        ind += 1;
    }
    return ind;
}

//Ajouter un nouveau processus à liste Proc
void ajouterProc(pid_t pidFils,char* commande1){
    int indice = 0;
    while (listeProc[indice].commandeProc!=NULL){
        indice ++;
    }
    //Allocation
    listeProc[indice].commandeProc = malloc(sizeof(char)*strlen(commande1));

    //Ajout du nouveau processus
    listeProc[indice].pidProc= pidFils;
    listeProc[indice].etatProc = Actif; 
    strcpy(listeProc[indice].commandeProc, commande1);
    nbProc++;
}

//Supprimer un processus de la liste
void supprimerProc(int indice){
    free(listeProc[indice].commandeProc);
    listeProc[indice].commandeProc = NULL;
}





/*----Sous-programmes pour sj, bg, fg----*/
//Suspendre un processus en arrière-plan
void suspendre(int i){
    if (0<=i-1 && i-1<nbProc && listeProc[i-1].etatProc == Actif){
        kill(listeProc[i-1].pidProc, SIGSTOP);
        listeProc[i-1].etatProc = Suspendu;
    }
    else {
        printf("Ce processus n'existe pas ou n'est pas actif \n");
    }
}

//Reprendre un processus en arrière-plan
void reprendreArriereP(int i){
    //On vérifie que le processus est suspendu
    if (0<=i-1 && i-1<nbProc && listeProc[i-1].etatProc == Suspendu){
        kill(listeProc[i-1].pidProc, SIGCONT);
        listeProc[i-1].etatProc = Actif;
    }
    else {
        printf("Ce processus n'existe pas ou n'est pas suspendu \n");
    }
}

//Reprendre un processus en avant-plan
void reprendreAvantP(int i){
    //On vérifie que le processus est suspendu
    if (0<=i-1 && i-1<nbProc && listeProc[i-1].etatProc == Suspendu){
        commande_avant_plan = listeProc[i-1].pidProc;
        kill(listeProc[i-1].pidProc, SIGCONT);
        listeProc[i-1].etatProc = Actif;
        while (commande_avant_plan > 0){
            pause();
        }
        supprimerProc(i-1);
    }
    else {
        printf("Ce processus n'existe pas ou n'est pas suspendu \n");
    }
}





/*-------------------Traitant du signal SIGCHLD----------------------------------------*/
void handler_sigchld(int signal_num) {
    int wstatus, fils_termine;

    fils_termine = waitpid(-1, &wstatus, WNOHANG | WUNTRACED | WCONTINUED);
    int indProc;

    if WIFEXITED(wstatus) {   /* fils terminé avec exit */

        //La commande en avant-plan est terminée
        if (fils_termine==commande_avant_plan){
            commande_avant_plan = 0;
        } else {
            indProc = TrouverProc(listeProc,fils_termine);
            listeProc[indProc].etatProc = Erreur;
            supprimerProc(indProc);
            nbProc--;
        }

        //La commande a été exécutée correctement
		if (wstatus == 0){
            printf("SUCCES\n");
        }
    }

    else if WIFSIGNALED(wstatus) {  /* fils tué par un signal */
        //Traitement de Ctrl-Z
        if (ctrlZ){
            ctrlZ=false;
            printf(" \n");
            ajouterProc(commande_avant_plan,commande->seq[0][0]);
            indProc = TrouverProc(listeProc,commande_avant_plan);
            listeProc[indProc].etatProc = Suspendu;
        }
        //Traitement de Ctrl-C
        else if (ctrlC){
            ctrlC=false;
            printf("\n");
        }

        if (fils_termine==commande_avant_plan){
            commande_avant_plan = 0;
        }
    }

    else if WIFSTOPPED(wstatus) { 
        if (fils_termine==commande_avant_plan){
            commande_avant_plan = 0;
        }
    }

    else if __WIFCONTINUED(wstatus) {
        //printf("Processus relancé\n");
    }
    return ;
}





/*------------------------Ctrl-C & Ctrl-Z----------------------------------------------*/
void traitementCtrlZ(int numero_signal)
{
    ctrlZ = true;
    if (commande_avant_plan>0){
        kill(commande_avant_plan, SIGKILL);
    }
}

void traitementCtrlC(int numero_signal)
{   
    ctrlC = true;
    if (commande_avant_plan>0){
        kill(commande_avant_plan, SIGSTOP);
    }
}





/*------------------------Code du main-------------------------------------------------*/
int main() {
    int pidJob, copieIN, copieOUT, desc_out, desc_in;
    bool sortie, sansfils, commande_cd, commande_exit, commande_lj, 
    commande_bg, commande_sj, commande_fg, commande_out, commande_in;
    char *direction;
    
    /* associer traitant sigchld à SIGCHLD, SIGTSTP, SIGINT */
    struct sigaction signalCHLD;
    sigemptyset(&signalCHLD.sa_mask);
    signalCHLD.sa_handler = handler_sigchld;
    signalCHLD.sa_flags = SA_RESTART;
    sigaction(SIGCHLD, &signalCHLD, NULL);
    
    struct sigaction signalTSTP;
    sigemptyset(&signalTSTP.sa_mask);
    signalTSTP.sa_handler = traitementCtrlZ;
    signalTSTP.sa_flags = SA_RESTART;
    sigaction(SIGTSTP, &signalTSTP, NULL);
    
    struct sigaction signalINT;
    sigemptyset(&signalINT.sa_mask);
    signalINT.sa_handler = traitementCtrlC;
    signalINT.sa_flags = SA_RESTART;
    sigaction(SIGINT, &signalINT, NULL); 

    do {
        //Affichage des chevrons et lecture de la commande
        printf(">>> ");
        /* Vidange du tampon de sortie pour que le fils le récupère vide */
        fflush(stdout);
        //Lecture de la commande
        commande = readcmd();
        
        if (commande->seq[0] != NULL){ //Condition correspondant à une entrée nulle

        //Création des conditions de sortie et de création de fils
        commande_exit = (strcmp("exit",commande->seq[0][0]) == 0);
        sortie = commande_exit;
        commande_cd = strcmp("cd",commande->seq[0][0]) == 0;
        commande_lj = strcmp("lj",commande->seq[0][0]) == 0;
        commande_sj = strcmp("sj",commande->seq[0][0]) == 0;
        commande_bg = strcmp("bg",commande->seq[0][0]) == 0;
        commande_fg = strcmp("fg",commande->seq[0][0]) == 0;
        sansfils = (commande_lj || commande_cd || commande_exit
        || commande_sj || commande_bg || commande_fg);

        //Booleens de redirection
        commande_out = (commande->out != NULL);
        commande_in = (commande->in != NULL);
            
            if (sansfils) {
                if (commande->seq[0][1]!=NULL)
                {
                    pidJob = atol(commande->seq[0][1]);
                }
                else{
                    pidJob = -1;
                }

                //Execution de cd   
                if (commande_cd) {
                    if ((strcmp(commande->seq[0][1], "~")) == 0){
                        direction = getenv("HOME");
                    }
                    else {
                        direction = commande->seq[0][1];
                    }
                    chdir(direction);
                    execlp("cd","cd", commande->in, NULL);
                    continue;      //affiche le prompt du mini-shell
                }

                //Execution de lj  
                else if (commande_lj) {
                    afficherListeProc(listeProc);
                    continue;     //affiche le prompt du mini-shell
                }

                //Execution de sj  
                else if (commande_sj) {
                    suspendre(pidJob);
                    continue;     //affiche le prompt du mini-shell
                }

                //Execution de bg  
                else if (commande_bg) {
                    reprendreArriereP(pidJob);
                    continue;     //affiche le prompt du mini-shell
                }

                //Execution de fg
                else if (commande_fg) {
                    reprendreAvantP(pidJob);
                    continue;     //affiche le prompt du mini-shell
                }
            }
            
            //Execution des commandes avec des fils
            else {
                copieOUT = dup(1);
                copieIN = dup(0);
                if (commande_in) {
                    desc_in = open(commande->in, O_WRONLY | O_CREAT | O_TRUNC, 0640);
                    dup2(desc_in,1);
                    close(desc_in);
                }
                if (commande_out){
                    desc_out = open(commande->out, O_WRONLY | O_CREAT | O_TRUNC, 0640);
                    dup2(desc_out,1);
                    close(desc_out);
                }

                pidFils = fork();

                /* bonne pratique : tester systématiquement le retour des appels système */
                if (pidFils == -1) {
                    NULL;
                }
                
                // Création du fils   
                if (pidFils == 0) {
                    execvp(commande->seq[0][0], commande->seq[0]);
                    printf ("ECHEC \n");
                    exit(2);                      
                }

                // Création du père
                else {
                    //Redirection vers l'entrée/sortie standard
                    dup2(copieIN,1);
                    dup2(copieOUT,0);
                    //Option "&" qui signifie une commande en arrière plan
                    //Soit on traite la commande en avant-plan
                    if (commande->backgrounded == NULL) {
                    commande_avant_plan = pidFils;
                        while (commande_avant_plan > 0){
                            pause();
                        }
                    }
                    //Soit on traite la commande en arrière-plan
                    else{
                        ajouterProc(pidFils,commande->seq[0][0]);
                    }
                }
            }
        } 
        
    } while (!sortie);
        
    //Affichage Salut à la sortie de la boucle 
    printf("Salut \n");
     
    return EXIT_SUCCESS; /* -> exit(EXIT_SUCCESS); pour le père */
}
