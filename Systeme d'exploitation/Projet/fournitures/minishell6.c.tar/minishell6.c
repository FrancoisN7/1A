#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h> /* wait */
#include <stdbool.h>
#include "readcmd.h"
#include <string.h>
#include <signal.h>
int nb_fils_termines ; /* variable globale car modifiée par le traitant */


/* Traitant du signal SIGCHLD */
void handler_sigchld(int signal_num) {
    int wstatus, fils_termine ;
    fils_termine = wait(&wstatus) ;
    nb_fils_termines++ ;
    if WIFEXITED(wstatus) {   /* fils terminé avec exit */
        printf("\nMon fils de pid %d a termine avec exit %d\n", 
                fils_termine, WEXITSTATUS(wstatus)) ;
    }
    else if WIFSIGNALED(wstatus) {  /* fils tué par un signal */
        printf("\nMon fils de pid %d a ete tue par le signal %d\n", 
                fils_termine, WTERMSIG(wstatus)) ;
    }
    return ;
}

int main() {
    struct cmdline *commande;
    pid_t pidFils , idFils;
    int codeTerm;
    bool sortie;
    bool sansfils;
    bool commande_cd, commande_exit, commande_lj;
    char *direction;
    char *listeProc[30];
    int indiceCour = 0;
    bool apActif = false; //arrière-plan non actif
    
    
    do {
        //Affichage des chevrons et lecture de la commande
        printf(">>> ");
        
        /* Vidange du tampon de sortie pour que le fils le récupère vide */
        fflush(stdout);
        commande = readcmd();
        
        //Création des conditions de sortie et de création de fils
        commande_exit = (commande != NULL && strcmp("exit",commande->seq[0][0]) == 0);
        sortie = (commande == NULL || commande-> seq[0] == NULL || commande_exit);
        commande_cd = (commande != NULL && strcmp("cd",commande->seq[0][0]) == 0);
        commande_lj = (commande != NULL && strcmp("lj",commande->seq[0][0]) == 0);
        sansfils = (commande_lj || commande_cd || commande_exit);
        
        //Execution de cd   
        if (commande_cd) {
            if ((strcmp(commande->seq[0][1], "~")) == 0){
                direction = getenv("HOME");
            }
            else {
                direction = commande->seq[0][1];
            }
            chdir(direction);
        continue ;         //affiche le prompt du mini-shell
        }
        
        if (sansfils) {
            execlp("cd","cd", commande->in, NULL);
        }
        
        //Execution des commandes avec des fils
        if (!sortie || !sansfils) {
        pidFils = fork();
        
        /* bonne pratique : tester systématiquement le retour des appels système */
        if (pidFils == -1) {
        NULL;
        }
        
        // Création du fils   
        if (pidFils == 0) {   
        execvp(commande->seq[0][0], commande->seq[0]);
        printf ("ECHEC \n");
        exit(2);
        }
        
        //Opération pour l'arrière plan !
        //On ajoute la commande à la liste des processus et on incrémente l'index
        if (!sortie && apActif) {
            listeProc[indiceCour] = commande->seq[0][0];
            indiceCour++;
        }
        
        //Execution de lj  
        if (commande_lj) {
            for (int i = 0; i<=indiceCour; i++){
                printf("%d\n",  i); //%s + listeProc[i],
            }
            
        continue;         //affiche le prompt du mini-shell
        }
        
        // Création du père
        else {
        //Option "&" qui empêche le wait
            if (commande->backgrounded == NULL) {
                idFils = wait(&codeTerm);
                if ( idFils == -1) {
                    perror ("wait");
                    exit (8);
                }
            else {
                apActif = true;
                /* associer traitant sigchld à SIGCHLD */
                int nb_fils_termines = 0;
                signal(SIGCHLD, handler_sigchld);
            }
            }
        }
        
        //Affichage de succès si la commande execvp a fonctionné
        if (WEXITSTATUS(codeTerm) != 2) {
            printf ("SUCCES \n");
        }
        }
    } while (!sortie);
    
    //Affichage Salut à la sortie de la boucle 
    printf("Salut \n");
    
    return EXIT_SUCCESS; /* -> exit(EXIT_SUCCESS); pour le père */
}

