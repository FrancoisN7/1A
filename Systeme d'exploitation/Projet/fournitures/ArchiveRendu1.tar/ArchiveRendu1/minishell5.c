#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h> /* wait */
#include <stdbool.h>
#include "readcmd.h"
#include <string.h>

int main() {
    struct cmdline *commande;
    pid_t pidFils , idFils;
    int codeTerm;
    bool sortie;
    bool sansfils;
    bool commande_cd;
    bool commande_exit;
    char *direction;
    
    
    do {
        //Affichage des chevrons et lecture de la commande
        printf(">>> ");
        commande = readcmd();
        
        //Création des conditions de sortie et de création de fils
        commande_exit = (commande != NULL && strcmp("exit",commande->seq[0][0]) == 0);
        sortie = (commande == NULL || commande-> seq[0] == NULL || commande_exit);
        commande_cd = (commande != NULL && strcmp("cd",commande->seq[0][0]) == 0);
        sansfils = (commande_cd || commande_exit);
        
        
        //Execution de cd   
        if (commande_cd) {
            if ((strcmp(commande->seq[0][1], "~")) == 0){
                direction = getenv("HOME");
            }
            else {
                direction = commande->seq[0][1];
            }
            chdir(direction);
        continue ;         //affiche le prompt du mini-shell
        }
        
        if (sansfils) {
            execlp("cd","cd", commande->in, NULL);
        }
        
        //Execution des commandes avec des fils
        if (!sortie || !sansfils) {
        pidFils = fork();
        
        /* bonne pratique : tester systématiquement le retour des appels système */
        if (pidFils == -1) {
        NULL;
        }
        
        // Création du fils   
        if (pidFils == 0) {   
        execvp(commande->seq[0][0], commande->seq[0]);
        printf ("ECHEC \n");
        exit(2);
        }
        
        // Création du père
        else {
        //Option "&" qui empêche le wait
            if (commande->backgrounded == NULL) {
                idFils = wait(&codeTerm);
                if ( idFils == -1) {
                    perror ("wait");
                    exit (8);
                }
            }
        }
        
        //Affichage de succès si la commande execvp a fonctionné
        if (WEXITSTATUS(codeTerm) != 2) {
        printf ("SUCCES \n");
        }
        }
    } while (!sortie);
    
    //Affichage Salut à la sortie de la boucle 
    printf("Salut \n");
    
    return EXIT_SUCCESS; /* -> exit(EXIT_SUCCESS); pour le père */
}

