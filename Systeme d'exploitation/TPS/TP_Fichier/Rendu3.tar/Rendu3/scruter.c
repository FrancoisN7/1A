#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

int main () {
    int indice;
    int BUFSIZE = 30;
    char texte[BUFSIZE];
    int lus;
    char buf[BUFSIZE];
    int desc;
    int retour;
    int wstatus;
    
    desc = open("temp.txt", O_RDWR | O_CREAT | O_TRUNC, 0700);
    if (desc < 0) {
        printf("Erreur ouverture") ;
    exit(1) ;
    }    
    
    for (int fils = 1 ; fils <= 2 ; fils++) {
          retour = fork() ;
  
         /* Bonne pratique : tester systématiquement le retour des appels système */
          if (retour < 0) {   /* échec du fork */
              printf("Erreur fork\n") ;
              /* Convention : s'arrêter avec une valeur > 0 en cas d'erreur */
              exit(1) ;
          }
         /* fils */
         if (retour == 0) {
             if (fils == 1) {
                indice = 1;
                while (indice != BUFSIZE + 1){
                    sprintf(texte, "%d", indice);
                    if (indice % 10 == 1){
                        lseek(desc, 0, SEEK_SET);
                    }
                    write(desc, texte, strlen(texte));
                    write(desc, "\n", strlen("\n"));
                    indice++;
                    sleep(1);
                }
             }
          }
             
             if (fils == 2) {
                do {
                    lus = read(desc, buf, BUFSIZE-1);
                    printf("%s", buf);
                } while (lus > 0);
                sleep(1);
             } 
         //Père 
         else {
            NULL;
         }
    }
    /* attendre la fin des fils */
    for (int fils = 1 ; fils <= 2 ; fils++) {
    /* attendre la fin d'un fils */
        wait(&wstatus);
    }
    close(desc);
    return EXIT_SUCCESS;
}
          
