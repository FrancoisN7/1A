#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h> /* wait */
#include <stdbool.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
    int BUFSIZE = 32;
    char buf [BUFSIZE] ; 
    int lus;
    int ecrit;
    int desc_source;
    int desc_dest;
    
    //Ouvrir le fichier source
    desc_source = open(argv[1], O_RDONLY, 0640);
    if (desc_source<0) {
        printf("Erreur lors de l'ouverture du fichier source.");
    }
    
    //Ouvrir le fichier destination
    desc_dest = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (desc_dest<0) {
        printf("Erreur lors de l'ouverture du fichier destination.");
    }
    
    do {
        lus = read(desc_source, buf, BUFSIZE-1);
        write(desc_dest, buf, lus);
    } while (lus > 0);
    
    //Fermer le fichier source
    close(desc_source);
    
    //Fermer le fichier destination
    close(desc_dest);
    
}
