#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h> /* wait */

int main() {
    char buf [30] ; /* contient la commande saisie au clavier */
    int ret = 1; /* valeur de retour de scanf */
    pid_t pidFils , idFils;
    int codeTerm;
    
    while (ret == 1) {
        printf(">>> ");
        ret = scanf("%s", buf);
        
        if (ret != 1){
            printf("Salut \n");
            exit(1);
        }
        
        pidFils = fork();
        /* bonne pratique : tester systématiquement le retour des appels système */
        if (pidFils == -1) {
        NULL;
        }
        if (pidFils == 0) { /* fils */   
        execlp(buf, buf, NULL);
        
        printf ("ECHEC \n");
        exit(2);
        }
    
        else { /* père */
        idFils = wait(&codeTerm);
        if ( idFils == -1) {
        perror ("wait");
            exit (8);
        }
        
        if (codeTerm != 512) {
        printf ("SUCCES \n");
        }
        }
    }
    return EXIT_SUCCESS; /* -> exit(EXIT_SUCCESS); pour le père */
}
